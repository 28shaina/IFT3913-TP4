package currencyConverter;


import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;


import java.util.HashMap;
import java.util.List;
import java.util.Map;


import static org.junit.jupiter.api.Assertions.assertEquals;


public class TestConvert {
    List<Currency> currencyList;
    Map<String, Currency> currencyMap;

    {
        currencyList = Currency.init();
        currencyMap = new HashMap<>();
        for (Currency c : currencyList) {
            currencyMap.put(c.getShortName(), c);
        }
    }

    @ParameterizedTest
    @CsvSource({
            "USD, USD, 1.0, 1.0",
            "USD, USD, 1.0, 2.0"
    })
    public void testConvertInPairs(String from, String to, double fromAmount, double expected) {
        assertEquals(expected,
                Currency.convert(fromAmount,
                        currencyMap.get(from).getExchangeValues().get(to)
                ), "test converting " + from + " -> " + to + " with amount " + fromAmount);
    }


}
